import flet as ft

GREEN = '#006076'
SECONDARY_COLOR = '#1d5b48'
BLACK = '#1d1d1d'
WHITE = '#ffffff'

def main(page: ft.page):
    page.title = "ahast - cyber security"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 50
    page.window_width, page.window_height = 900, 800

    logoImg = ft.Image(src=f"/icons/icon.png")
    headingTxt = ft.Text(value='You are safe now!', style=ft.TextThemeStyle.DISPLAY_MEDIUM, font_family='JetBrains Mono')

    welcomeRow = ft.Row(controls=[logoImg, headingTxt], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    tileUpdate = ft.ElevatedButton(
        content=ft.Row(
            [ft.Icon(ft.icons.UPDATE), ft.Text("Update database")], alignment="center", spacing=5
        ),
        bgcolor= GREEN,
        color = WHITE,
        icon_color=WHITE,
        width=200,
        height=200,
    )

    tileBackup = ft.ElevatedButton(
        content=ft.Row(
            [ft.Icon(ft.icons.SETTINGS_BACKUP_RESTORE), ft.Text("Backup and Restore")], alignment="center", spacing=5
        ),
        bgcolor=GREEN,
        color = WHITE,
        icon_color=WHITE,
        width=200,
        height=200,
    )

    tileMoney = ft.ElevatedButton(
        content=ft.Row(
            [ft.Icon(ft.icons.CREDIT_CARD), ft.Text("Safe Money")], alignment="center", spacing=5
        ),
        bgcolor=GREEN,
        color = WHITE,
        icon_color=WHITE,
        width=200,
        height=200,
    )

    tilePrivacy = ft.ElevatedButton(
        content=ft.Row(
            [ft.Icon(ft.icons.PRIVACY_TIP), ft.Text("Privacy Protection")], alignment="center", spacing=5
        ),
        bgcolor=GREEN,
        color = WHITE,
        icon_color=WHITE,
        width=200,
        height=200,
    )

    tileScan = ft.ElevatedButton(
        content=ft.Row(
            [ft.Icon(ft.icons.SCREEN_SEARCH_DESKTOP_OUTLINED), ft.Text("Scan")], alignment="center", spacing=5
        ),
        on_click=None,
        bgcolor=GREEN,
        color = WHITE,
        icon_color=WHITE,
        width=200,
        height=200,
    )

    tileClean = ft.ElevatedButton(
        content=ft.Row(
            [ft.Icon(ft.icons.CLEANING_SERVICES), ft.Text("Clean")], alignment="center", spacing=5
        ),
        bgcolor=GREEN,
        color = WHITE,
        icon_color=WHITE,
        width=200,
        height=200,
    )

    actionsRow1 = ft.Row(controls=[tileScan, tileUpdate, tileClean], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
    actionsRow2 = ft.Row(controls=[tilePrivacy, tileMoney, tileBackup], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    page.add(welcomeRow, actionsRow1, actionsRow2)
    page.update()

ft.app(assets_dir='media', target=main)
